# The prompts

You do not need to memorize these. We use them together on October 15. They are here so you can start early if you want to.

Anything in [brackets] is yours to replace.

---

## Before October 15 (optional, 10 minutes)

**Find out what your course looks like to AI.** Open Claude, upload your syllabus, and paste:

> Read my syllabus. In plain language, tell me: what does this course actually ask students to be able to do, and which of those things could a student hand entirely to AI? Be blunt.

**Stress-test one assignment.** Upload one assignment and paste:

> Here is an assignment from [course]. First, complete it the way a student relying only on AI would. Then tell me which parts AI handled easily. Finally, suggest 3 changes that need the student's own thinking or in-class work, without making it harder for me to grade.

---

## On October 15, in order

**1 · The semester plan**

> Read every file in this folder. Build a week-by-week plan for [course] for a [number]-week semester, matching the topics and dates in my syllabus. Save it as `99-new-course/semester-plan.md`.

**2 · The first module**

> Build Module 1 in `99-new-course/module-01`, matching the notation and difficulty of my existing materials: a student reading guide, a practice set of [number] problems, an answer key with one-sentence explanations, and a class plan for each meeting that week.

**3 · Two redesigned assignments**

> Take the two assignments in `02-assessments`. For each one, show me which parts AI does easily, then rewrite it so it needs the student's own data, in-class work, or their own voice. Keep my learning goals and my grading time the same. Save both in `99-new-course/redesigned-assignments.md`.

**4 · Rubrics**

> Write a rubric for each redesigned assignment. Before you write anything, ask me questions one at a time until you know what I actually grade. Ask no more than 5.

**5 · The Canvas shell**

> Build a Canvas module plan for this course in `99-new-course/canvas/`. One file per module, listing the module title, the pages, the assignments with due dates from my schedule, and the text of each page ready to paste into Canvas. Use plain headings, no special formatting.

**6 · The AI policy**

> Write an AI policy for my syllabus. My position is [what students may and may not use AI for]. Keep it under 150 words, in plain language a first-year student understands, and match the tone of the rest of my syllabus.

---

## The two habits that make these work

**Let it interview you.** Add this to any prompt and the result stops being generic:

> Before you write anything, ask me questions one at a time until you have what you need. Ask no more than 5.

**Make it critique itself.** After any draft:

> Point out the 3 weakest parts of what you just wrote, then fix them.
