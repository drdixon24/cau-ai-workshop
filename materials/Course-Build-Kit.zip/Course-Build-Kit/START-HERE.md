# Start here

**What this is:** a folder for gathering one course, so that on **Thursday, October 15** we can rebuild it together. You bring the raw material. You leave with a redesigned course.

**Time it takes:** about 30 minutes, spread over the next few weeks. You are not writing anything new. You are collecting what you already have.

---

## Step 1 · Copy this folder and name it after your course

Copy the whole `Course-Build-Kit` folder to your Desktop or Documents, and rename it something like `MATH-1113-Rebuild` or `Advising-Handbook-Rebuild`.

Keep the numbered folders inside. The numbers are the order we work in on October 15.

## Step 2 · Pick one course

One. Not your whole load.

Pick the one that fits any of these:
- You teach it most often
- It frustrates you most
- Students struggle in it every semester
- You are about to redesign it anyway

Staff: this works for a handbook, an onboarding process, a training, or a set of forms. Same folders, same idea.

## Step 3 · Drop your files in

Open each numbered folder. Inside each one is a short note telling you what belongs there. Drag your files in. Any format works: Word, PDF, PowerPoint, Pages, plain text, screenshots.

| Folder | What goes in |
|---|---|
| `01-course-info` | Syllabus, catalog description, schedule |
| `02-assessments` | Old exams, quizzes, assignments, rubrics |
| `03-materials` | Lecture notes, slides, handouts, reading list |
| `04-canvas` | Canvas export or a list of your current modules |
| `05-policies` | Attendance, late work, AI policy, accessibility |
| `99-new-course` | Leave empty. This is where the new course lands |

**Do not reorganize or clean anything up.** Messy is fine. Old is fine. Half-finished is fine.

## Step 4 · Take the student data out

This is the one rule that matters.

**Remove before you drop a file in:**
- Student names
- Grades and grade reports
- ID numbers
- Any graded or submitted student work

Blank copies only. FERPA still applies to everything you put in this folder. If a file has a student's work on it, leave it out or delete that part first.

When in doubt, leave it out. We can work without it.

## Step 5 · Answer four questions

Open `CHECKLIST.md` in this folder and write your answers at the bottom. They take five minutes and they shape everything we build.

---

## What happens on October 15

**Thursday, October 15, 12:30 PM · McPheeters-Dennis Hall, Room 150B**

We work through your folder in order, and you leave with:

1. **A week-by-week plan** for the whole semester, built from your syllabus
2. **Materials for your first module**: reading guide, practice set, answer key, class plan
3. **Two redesigned assignments** that are harder to hand to AI, without being harder to grade
4. **Rubrics** for both of them
5. **A Canvas module plan**, plus pages and assignment text you can paste straight into your shell
6. **An AI policy** for your syllabus, written in your voice

**Bring:** your laptop, this folder with files in it, and your Canvas login.

## If you get stuck

Everything from the September workshop is on the workshop site, including the setup guides and the prompts. Or email Dr. Dixon before October 15 and we will sort it out ahead of time, not during the session.

**The one thing that would sink your October 15:** showing up with an empty folder. Twenty minutes of collecting now is the difference between leaving with a rebuilt course and leaving with notes about one.
