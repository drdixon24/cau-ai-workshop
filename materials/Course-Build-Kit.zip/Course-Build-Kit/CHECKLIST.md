# Ready for October 15?

Print this page, or check the boxes right here.

## Files collected

- [ ] **Syllabus** is in `01-course-info`
- [ ] **At least one old exam, quiz, or major assignment** is in `02-assessments`
- [ ] **At least one set of notes, slides, or handouts** is in `03-materials`
- [ ] **Canvas export or a typed list of my modules** is in `04-canvas` (skip if the course is not in Canvas)
- [ ] **My policies** are in `05-policies`, or I know they are in the syllabus already
- [ ] `99-new-course` is **empty**

## Student data check

- [ ] No student names anywhere in this folder
- [ ] No grades or grade reports
- [ ] No ID numbers
- [ ] No graded or submitted student work, only blank copies

## Bring on the day

- [ ] Laptop, charged
- [ ] This folder, on the laptop (not only in the cloud)
- [ ] Canvas login that works
- [ ] Claude account, signed in

---

# Four questions

Write your answers here. Five minutes. These shape everything we build on October 15.

**1. Which course are we rebuilding, and who takes it?**
> (example: MATH 1113, first-year students, mostly non-majors, 30 per section)



**2. What goes wrong every single semester?**
> (example: they memorize procedures and cannot explain what an answer means)



**3. What do you most want off your plate?**
> (example: writing a new quiz every Thursday night)



**4. If one thing about this course were different in December, what would it be?**
> (example: students can read a statistic in the news and say whether to trust it)


